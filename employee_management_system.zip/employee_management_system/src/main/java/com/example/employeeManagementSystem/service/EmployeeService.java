package com.example.employeeManagementSystem.service;

import com.example.employeeManagementSystem.dto.AddressDetails;
import com.example.employeeManagementSystem.dto.EmployeeDetails;
import com.example.employeeManagementSystem.dto.EmployeeRequest;
import com.example.employeeManagementSystem.entity.Address;
import com.example.employeeManagementSystem.entity.Employee;
import com.example.employeeManagementSystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public String addEmployee(EmployeeRequest employeeRequest) {

        if(employeeRequest.getFirstName() == null || employeeRequest.getLastName() == null || employeeRequest.getEmail() == null
        || employeeRequest.getMob() == null){
            return "Employee addition failed. All fields are required.";
        }
        Address address = new Address(employeeRequest.getAddressRequest().getStreetAddress(), employeeRequest.getAddressRequest().getCity(),
                employeeRequest.getAddressRequest().getState(), employeeRequest.getAddressRequest().getCountry(), employeeRequest.getAddressRequest().getPin());


        Employee employee = new Employee(employeeRequest.getFirstName(), employeeRequest.getLastName(), employeeRequest.getEmail(),
                employeeRequest.getMob(), address);

        employee.setId(employeeRequest.getId());
        employee.setFirstName(employeeRequest.getFirstName());
        employee.setLastName(employeeRequest.getLastName());
        employee.setEmail(employeeRequest.getEmail());
        employee.setMob(employeeRequest.getMob());

        address = employee.getAddress();
        address.setStreetAddress(employeeRequest.getAddressRequest().getStreetAddress());
        address.setCity(employeeRequest.getAddressRequest().getCity());
        address.setState(employeeRequest.getAddressRequest().getState());
        address.setCountry(employeeRequest.getAddressRequest().getCountry());
        address.setPin(employeeRequest.getAddressRequest().getPin());
        employee.setAddress(address);

        employeeRepository.save(employee);

        return "Employee Added Successfully";
    }

    public String updateEmployee(EmployeeRequest employeeRequest){

        if(employeeRequest.getFirstName() == null || employeeRequest.getLastName() == null || employeeRequest.getEmail() == null
                || employeeRequest.getMob() == null){
            return "Employee updation failed. All fields are required.";
        }

        Employee employee = employeeRepository.getById(employeeRequest.getId());
        Address address = new Address(employeeRequest.getAddressRequest().getStreetAddress(), employeeRequest.getAddressRequest().getCity(),
                employeeRequest.getAddressRequest().getState(), employeeRequest.getAddressRequest().getCountry(), employeeRequest.getAddressRequest().getPin());


         employee = new Employee(employeeRequest.getFirstName(), employeeRequest.getLastName(), employeeRequest.getEmail(),
                employeeRequest.getMob(), address);

        employee.setId(employeeRequest.getId());
        employee.setFirstName(employeeRequest.getFirstName());
        employee.setLastName(employeeRequest.getLastName());
        employee.setEmail(employeeRequest.getEmail());
        employee.setMob(employeeRequest.getMob());

        address = employee.getAddress();
        address.setStreetAddress(employeeRequest.getAddressRequest().getStreetAddress());
        address.setCity(employeeRequest.getAddressRequest().getCity());
        address.setState(employeeRequest.getAddressRequest().getState());
        address.setCountry(employeeRequest.getAddressRequest().getCountry());
        address.setPin(employeeRequest.getAddressRequest().getPin());
        employee.setAddress(address);

        employeeRepository.save(employee);
        return "Employee Successfully updated";
    }

    public String deleteEmployee(Long id){

        Employee employee = employeeRepository.getById(id);
        employeeRepository.delete(employee);
        return "Employee Successfully deleted";
    }

    public EmployeeDetails fetchEmployee(Long id){
        Employee employee = employeeRepository.getById(id);
        EmployeeDetails employeeDetails = new EmployeeDetails();
        AddressDetails addressDetails = new AddressDetails();

        employeeDetails.setId(employee.getId());
        employeeDetails.setFirstName(employee.getFirstName());
        employeeDetails.setLastName(employee.getLastName());
        employeeDetails.setEmail(employee.getEmail());
        employeeDetails.setMob(employee.getMob());

        addressDetails.setStreetAddress(employee.getAddress().getStreetAddress());
        addressDetails.setCity(employee.getAddress().getCity());
        addressDetails.setState(employee.getAddress().getState());
        addressDetails.setCountry(employee.getAddress().getCountry());
        addressDetails.setPin(employee.getAddress().getPin());
        employeeDetails.setAddressDetails(addressDetails);

        return employeeDetails;
    }

    public List<EmployeeDetails> fetchAllEmployee(){

        List <EmployeeDetails> employeeDetailsList  = new ArrayList<>();
        List<Employee> employeeList = employeeRepository.findAll();
        for(Employee employee : employeeList) {
            EmployeeDetails employeeDetails = new EmployeeDetails();
            AddressDetails addressDetails = new AddressDetails();
            employeeDetails.setId(employee.getId());
            employeeDetails.setFirstName(employee.getFirstName());
            employeeDetails.setLastName(employee.getLastName());
            employeeDetails.setEmail(employee.getEmail());
            employeeDetails.setMob(employee.getMob());

            addressDetails.setStreetAddress(employee.getAddress().getStreetAddress());
            addressDetails.setCity(employee.getAddress().getCity());
            addressDetails.setState(employee.getAddress().getState());
            addressDetails.setCountry(employee.getAddress().getCountry());
            addressDetails.setPin(employee.getAddress().getPin());
            employeeDetails.setAddressDetails(addressDetails);
            employeeDetailsList.add(employeeDetails);
        }

        return employeeDetailsList;
    }
}
