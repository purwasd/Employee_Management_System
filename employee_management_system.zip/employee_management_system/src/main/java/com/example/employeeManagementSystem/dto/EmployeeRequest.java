package com.example.employeeManagementSystem.dto;

public class EmployeeRequest {

    private long id;
    private String firstName;
    private String lastName;
    private String email;
    private String mob;
    private AddressRequest addressRequest;

    public EmployeeRequest() {
    }

    public EmployeeRequest(long id, String firstName, String lastName, String email, String mob, AddressRequest addressRequest) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.mob = mob;
        this.addressRequest = addressRequest;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMob() {
        return mob;
    }

    public void setMob(String mob) {
        this.mob = mob;
    }

    public AddressRequest getAddressRequest() {
        return addressRequest;
    }

    public void setAddressRequest(AddressRequest addressRequest) {
        this.addressRequest = addressRequest;
    }
}
