package com.example.employeeManagementSystem.controller;


import com.example.employeeManagementSystem.dto.EmployeeDetails;
import com.example.employeeManagementSystem.dto.EmployeeRequest;
import com.example.employeeManagementSystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @RequestMapping(value = "/addEmployee", method = RequestMethod.POST)
    public String addEmployee(@RequestBody EmployeeRequest employeeRequest){

        String response = employeeService.addEmployee(employeeRequest);
        return response;
    }

    @RequestMapping(value = "/updateEmployee", method = RequestMethod.PUT)
    public String updateEmployee(@RequestBody EmployeeRequest employeeRequest){

        String response = employeeService.updateEmployee(employeeRequest);
        return response;
    }

    @RequestMapping(value = "/deleteEmployee/{id}", method = RequestMethod.DELETE)
    public String deleteEmployee(@PathVariable Long id){

        String response = employeeService.deleteEmployee(id);
        return response;
    }

    @RequestMapping(value = "/fetchEmployee/{id}", method = RequestMethod.GET)
    public EmployeeDetails fetchEmployee(@PathVariable Long id){

        EmployeeDetails response = employeeService.fetchEmployee(id);
        return response;
   }

    @RequestMapping(value = "/fetchAllEmployee", method = RequestMethod.GET)
    public List<EmployeeDetails> fetchAllEmployee(){

        List<EmployeeDetails> response = employeeService.fetchAllEmployee();
        return response;
    }

}
